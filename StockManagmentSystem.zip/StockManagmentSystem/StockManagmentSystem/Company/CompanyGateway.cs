﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Company
{
    public class CompanyGateway : GetWay
    {
        public int Save(Company aCompany)
        {
            Connection.Open();
            Query = "INSERT INTO Company(CompanyName) Values('" + aCompany.CompanyName + "')";
            Command = new SqlCommand(Query, Connection);
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public bool IsExist(string CompanyName)
        {
            Connection.Open();
            Query = "SELECT * FROM Company  WHERE CompanyName ='" + CompanyName + "'";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            bool hasRow = Reader.HasRows;
            Reader.Close();
            Connection.Close();
            return hasRow;
        }


        public List<Company> GetAllCompany()
        {
            Connection.Open();
            Query = "SELECT * FROM Company";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Company> company = new List<Company>();
            int SL = 0;

            while (Reader.Read())
            {
                SL = SL + 1;
                Company aCompany = new Company();
                aCompany.CompanyName = Reader["CompanyName"].ToString();
                aCompany.CompanyId = (int) Reader["CompanyId"];
                aCompany.SL = SL;
                company.Add(aCompany);
            }
            Reader.Close();
            Connection.Close();
            return company;
        }
    }
}