﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace StockManagmentSystem.Company
{
    public partial class CompanySetup : System.Web.UI.Page
    {
        CompanyStockManager aCompanyStockManager = new CompanyStockManager();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CompanyNameSaveButton_Click(object sender, EventArgs e)
        {
            Company aCompany = new Company();
            aCompany.CompanyName = CompanyNameTextBox.Text;
            aCompanyStockManager.Save(aCompany);
            MessageBox.Show("Company are Save.");
            
             
            List<Company> company = aCompanyStockManager.GetAllCompany();
            CompanyGridView.DataSource = company;
            CompanyGridView.DataBind();
            
       }

      
    }
}