﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using StockManagmentSystem.Category;
using StockManagmentSystem.Company;
using StockManagmentSystem.Item;

namespace StockManagmentSystem.Item_Summary
{
    
    public partial class ItemSummary : System.Web.UI.Page
    {
        CategoryStockManager aCategoryStockManager = new CategoryStockManager();
        CompanyStockManager aCompanyStockManager = new CompanyStockManager();
        ItemStockManager aItemStockManager = new ItemStockManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCompany();
                GetAllCategory();
            }
        }

        protected void SearchItemButton_Click(object sender, EventArgs e)
        {
            
            Item.Item aItem = new Item.Item();
            aItem.CategoryId = Convert.ToInt32(CategoryDropDownList.SelectedValue);
            aItem.CompanyId = Convert.ToInt32(CompanyDropDownList.SelectedValue);
            List<Item.Item>items = aItemStockManager.GetItemSummary(aItem);

            SummaryGridView.DataSource = items;
            SummaryGridView.DataBind();

        }

        public void GetAllCompany()
        {
            List<Company.Company> aCompany = aCompanyStockManager.GetAllCompany();
            CompanyDropDownList.DataSource = aCompany;
            CompanyDropDownList.DataTextField = "CompanyName";
            CompanyDropDownList.DataValueField = "CompanyId";
            CompanyDropDownList.DataBind();


        }

        public void GetAllCategory()
        {
            List<Category.Category> aCategore = aCategoryStockManager.GetAllCategory();
            CategoryDropDownList.DataSource = aCategore;
            CategoryDropDownList.DataTextField = "CategoryName";
            CategoryDropDownList.DataValueField = "CategoryId";
            CategoryDropDownList.DataBind();

        }
    }
}