﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Web;

namespace StockManagmentSystem.Item
{
    public class Item
    {
        public int SL { get; set; }
        public int ItemId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string ItemName { get; set; }
        public int ItemReorderLevel { get; set; }
        public int AvailableQuantity { get; set; }
    }
}