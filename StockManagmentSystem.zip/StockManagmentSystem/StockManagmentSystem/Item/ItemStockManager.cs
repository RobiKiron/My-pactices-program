﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Item
{
    public class ItemStockManager
    {
        ItemStockGateway aItemStockGateway = new ItemStockGateway();
        public string Save(Item aItem)
        {
            int rowAffected = aItemStockGateway.Save(aItem);
            if (rowAffected > 0)
                return "Saved";
            else
            {
                return "Failed";
            }
        }

        public List<Item> GetAllItem()
        {
            return aItemStockGateway.GetAllItem();
        }

        public List<Item> GetItemSummary(Item aItem)
        {
            return aItemStockGateway.GetItemSummary(aItem);
        }


        public int GetReorderLevel(int ItemId)
        {
            return aItemStockGateway.GetReorderLevel(ItemId);
        }
    }
}