﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using StockManagmentSystem.Stockout;

namespace StockManagmentSystem.Sales_Summary
{
    public partial class SalesSummary : System.Web.UI.Page
    {
        StockOutputManager aStockOutputManager=new StockOutputManager();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SearchButton_Click(object sender, EventArgs e)
        {
            string from, to;
            from = FromTextBox.Text;
            to = ToTextBox.Text;
            List<StockOutput>aStockOutputs= aStockOutputManager.GetAllSaleItem(from,to);

            SaleGridView.DataSource = aStockOutputs;
            SaleGridView.DataBind();
        }
    }
}