﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using StockManagmentSystem.Company;
using StockManagmentSystem.Item;

namespace StockManagmentSystem.StockIn
{
    public partial class StockIN : System.Web.UI.Page
    {
        StockInputManager aStockinputManager = new StockInputManager();
        StockInput aStockInput = new StockInput();
        


        public void GetAllCompany()
        {
            List<Company.Company> aCompany = aStockinputManager.GetAllCompany();
            StockInCompanyDropDownList.DataSource = aCompany;
            StockInCompanyDropDownList.DataTextField = "CompanyName";
            StockInCompanyDropDownList.DataValueField = "CompanyId";
            StockInCompanyDropDownList.DataBind();

        }

        public void GetAllItem(string selectedValue)
        {
            List<Item.Item> aItems = aStockinputManager.GetAllItem(selectedValue);
            
            StockInItemDropDownList.DataSource = aItems;
            StockInItemDropDownList.Items.Clear();
            StockInItemDropDownList.DataTextField = "ItemName";
            StockInItemDropDownList.DataValueField = "ItemId";
            StockInItemDropDownList.DataBind();

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCompany();
               
            }

           
        }

        protected void StockInSaveButton_Click(object sender, EventArgs e)
        {

            aStockInput.CompanyId = Convert.ToInt32(StockInCompanyDropDownList.SelectedValue);
            aStockInput.ItemId = Convert.ToInt32(StockInItemDropDownList.SelectedValue);
            aStockInput.SIQuantity = Convert.ToInt32(StockInQuantityTextBox.Text);

            aStockInput.AvailableQuantity = (Convert.ToInt32(StockInAvailableQuantityTextBox.Text))  + (aStockInput.SIQuantity);
            
            aStockinputManager.Saved(aStockInput);
            MessageBox.Show("Stock Quantity are inputed.");
        }

     
        protected void StockInCompanyDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetAllItem(StockInCompanyDropDownList.SelectedValue);
        }

        protected void StockInItemDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            StockInReorderLevelTextBox.Text = aStockinputManager.GetReorderLevel(Convert.ToInt32(StockInItemDropDownList.SelectedValue)).ToString();
            StockInAvailableQuantityTextBox.Text =
                aStockinputManager.GetSIQuantity(Convert.ToInt32(StockInItemDropDownList.SelectedValue))
                    .ToString();
        }
    }
}