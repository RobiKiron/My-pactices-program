﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.StockIn
{
    public class StockInputGateway : GetWay
    {

        public List<Company.Company> GetAllCompany()
        {
            Connection.Open();
            Query = "SELECT * FROM Company";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Company.Company> company = new List<Company.Company>();


            while (Reader.Read())
            {
                Company.Company aCompany = new Company.Company();
                aCompany.CompanyName = Reader["CompanyName"].ToString();
                aCompany.CompanyId = (int)Reader["CompanyId"];
                company.Add(aCompany);
            }
            Reader.Close();
            Connection.Close();
            return company;
        }



        public List<Item.Item> GetAllItem(string selectedValue)
        {
           Connection.Open();
           Query = "Select ItemID,ItemName from Item where CompanyId = '"+selectedValue+"';";
           Command = new SqlCommand(Query, Connection);
           Reader = Command.ExecuteReader();
           List<Item.Item> items = new List<Item.Item>();

           while (Reader.Read())
           {
               Item.Item aitItem = new Item.Item();
               aitItem.ItemId = (int) Reader["ItemId"];
               aitItem.ItemName= (string) Reader["ItemName"];
               
               items.Add(aitItem);
           }
           Reader.Close();
           Connection.Close();
           return items;

        }


        public int GetReorderLevel(int ItemId)
        {
            int ReorderLevel=0 ;
            Connection.Open();
            Query = "select * from Item where ItemId = '" + ItemId + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                ReorderLevel = (int)Reader["ReorderLevel"];
                
            }

            Reader.Close();
            Connection.Close();
            return ReorderLevel;
        }

        public int Saved(StockInput aStockInput)
        {
            Connection.Open();
            Query = "INSERT INTO StockIn (ItemId, StockInQuantity,StockInTime)VALUES ('" + aStockInput.ItemId + "','" + aStockInput.SIQuantity + "','" + DateTime.Now.ToString("yyyy-MM-dd ") + "'); UPDATE Item SET AvailableQuantity = '" + aStockInput.SIQuantity + "' WHERE ItemId = '" + aStockInput.ItemId + "';";
            Command = new SqlCommand(Query, Connection);

            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public int GetSIQuantity(int ItemId)
        {
            int available = 0;
            Connection.Open();
            Query = "select * from Item where ItemId = '" + ItemId + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                available = (int)Reader["AvailableQuantity"];
            }

            Reader.Close();
            Connection.Close();
            return available;
        }

    }
}