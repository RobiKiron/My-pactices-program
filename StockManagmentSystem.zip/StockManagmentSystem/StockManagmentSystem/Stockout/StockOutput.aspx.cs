﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace StockManagmentSystem.Stockout
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        StockOutputManager aStockOutputManager = new StockOutputManager();
        StockOutput aStockOutput = new StockOutput();
        StockOutputGateway aStockOutputGateway =new StockOutputGateway();
         List<StockOutput> aStockOutputList = new List<StockOutput>();
         
     


        public void GetAllCompany()
        {
            List<Company.Company> aCompany = aStockOutputManager.GetAllCompany();
            StockOutCompanyDropDownList.DataSource = aCompany;
            StockOutCompanyDropDownList.DataTextField = "CompanyName";
            StockOutCompanyDropDownList.DataValueField = "CompanyId";
            StockOutCompanyDropDownList.DataBind();

        }

        public void GetAllItem(string selectedValue)
        {
            List<Item.Item> aItems = aStockOutputManager.GetAllItem(selectedValue);

            StockOutItemDropDownList.DataSource = aItems;
            StockOutItemDropDownList.Items.Clear();
            StockOutItemDropDownList.DataTextField = "ItemName";
            StockOutItemDropDownList.DataValueField = "ItemId";
            StockOutItemDropDownList.DataBind();

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCompany();
            }

        }

        protected void StockOutCompanyDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetAllItem(StockOutCompanyDropDownList.SelectedValue);
        }

        protected void StockOutItemDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            StockOutReorderLevelTextBox.Text = aStockOutputManager.GetReorderLevel(Convert.ToInt32(StockOutItemDropDownList.SelectedValue)).ToString();
            StockOutAvailableQuantityTextBox.Text =
               aStockOutputManager.GetAvailableQuantity(Convert.ToInt32(StockOutItemDropDownList.SelectedValue))
                   .ToString();
        }

        protected void StockOutAddButton_Click(object sender, EventArgs e)
        {
            aStockOutput.CompanyId = Convert.ToInt32(StockOutCompanyDropDownList.SelectedValue);
            aStockOutput.ItemId = Convert.ToInt32(StockOutItemDropDownList.SelectedValue);
            aStockOutput.StockOutQunatity = Convert.ToInt32(StockOutQuantityTextBox.Text);

            if ((Convert.ToInt32(StockOutAvailableQuantityTextBox.Text)) >= (aStockOutput.StockOutQunatity))
            {
                aStockOutput.AvailableQuantity = (Convert.ToInt32(StockOutAvailableQuantityTextBox.Text)) - (aStockOutput.StockOutQunatity);
                aStockOutputManager.AddStockOutputs(aStockOutput);

                aStockOutputList = aStockOutputManager.GetAllStockOut();
                StockOutGridView.DataSource = aStockOutputList;
                StockOutGridView.DataBind();
            }
            else
            {
                MessageBox.Show("Available Quantity is less than Out Quantity!");
            }
  
        }

        public void ClearEditText()
        {
            StockOutReorderLevelTextBox.Text = " ";
            StockOutAvailableQuantityTextBox.Text = " ";
            StockOutQuantityTextBox.Text = " ";
        }
        protected void SellButton_Click(object sender, EventArgs e)
        {
            aStockOutputList = aStockOutputManager.GetAllStockOut();
            aStockOutputManager.SellStockOutputlist(aStockOutputList);
            aStockOutputManager.DeletStockOutputs();
            ClearEditText();

            aStockOutputList = aStockOutputGateway.GetAllStockOut();
            StockOutGridView.DataSource = aStockOutputList;
            StockOutGridView.DataBind();
        }

        protected void DamageButton_Click(object sender, EventArgs e)
        {
            aStockOutputList = aStockOutputManager.GetAllStockOut();
            aStockOutputManager.DamageStockOutputlist(aStockOutputList);
            aStockOutputManager.DeletStockOutputs();
            ClearEditText();

            aStockOutputList = aStockOutputGateway.GetAllStockOut();
            StockOutGridView.DataSource = aStockOutputList;
            StockOutGridView.DataBind();
        }

        protected void LostButton_Click(object sender, EventArgs e)
        {
            aStockOutputList = aStockOutputManager.GetAllStockOut();
            aStockOutputManager.LostStockOutputlist(aStockOutputList);
            aStockOutputManager.DeletStockOutputs();
            ClearEditText();

            aStockOutputList = aStockOutputGateway.GetAllStockOut();
            StockOutGridView.DataSource = aStockOutputList;
            StockOutGridView.DataBind();
        }

       


        
        
    }
}