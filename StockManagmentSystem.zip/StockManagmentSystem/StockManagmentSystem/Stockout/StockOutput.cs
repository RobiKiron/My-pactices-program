﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Stockout
{
    public class StockOutput
    {
        public int SL{ get; set; }
        public int StockOutId { get; set; }
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public int StockOutQunatity { get; set; }
        public int AvailableQuantity { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public int StockOutTypeId { get; set; }
        public DateTime StockOutTime { get; set; }
    }
}