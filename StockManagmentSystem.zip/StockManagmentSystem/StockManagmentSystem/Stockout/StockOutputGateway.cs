﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace StockManagmentSystem.Stockout
{
    public class StockOutputGateway:GetWay
    {
        public List<Company.Company> GetAllCompany()
        {
            Connection.Open();
            Query = "SELECT * FROM Company";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Company.Company> company = new List<Company.Company>();


            while (Reader.Read())
            {
                Company.Company aCompany = new Company.Company();
                aCompany.CompanyName = Reader["CompanyName"].ToString();
                aCompany.CompanyId = (int)Reader["CompanyId"];
                company.Add(aCompany);
            }
            Reader.Close();
            Connection.Close();
            return company;
        }



        public List<Item.Item> GetAllItem(string selectedValue)
        {
            Connection.Open();
            Query = "Select ItemID,ItemName from Item where CompanyId = '" + selectedValue + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Item.Item> items = new List<Item.Item>();

            while (Reader.Read())
            {
                Item.Item aitItem = new Item.Item();
                aitItem.ItemId = (int)Reader["ItemId"];
                aitItem.ItemName = (string)Reader["ItemName"];

                items.Add(aitItem);
            }
            Reader.Close();
            Connection.Close();
            return items;

        }


        public int GetReorderLevel(int ItemId)
        {
            int ReorderLevel = 0;
            Connection.Open();
            Query = "select * from Item where ItemId = '" + ItemId + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                ReorderLevel = (int)Reader["ReorderLevel"];
            }

            Reader.Close();
            Connection.Close();
            return ReorderLevel;
        }

        public int GetAvailableQuantity(int ItemId)
        {
            int avilable = 0;
            Connection.Open();
            Query = "select * from Item where ItemId = '" + ItemId + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                avilable = (int)Reader["AvailableQuantity"];
            }

            Reader.Close();
            Connection.Close();
            return avilable;
        }

        public int DeletStockOutputs()
        {
            Connection.Open();
            Query = "delete from StockOutputs;";
            Command = new SqlCommand(Query, Connection);
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public int AddStockOutputs(StockOutput aStockOutput)
        {
            Connection.Open();
            Query = "insert into StockOutputs (CompanyId,ItemId,StockOutQunatity)values('" + aStockOutput.CompanyId + "','" + aStockOutput.ItemId + "','" + aStockOutput.StockOutQunatity + "');UPDATE Item SET AvailableQuantity = '" + aStockOutput.AvailableQuantity + "' WHERE ItemId = '" + aStockOutput.ItemId + "';";
            Command = new SqlCommand(Query, Connection);
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }


        public List<StockOutput> GetAllStockOut()
        {
            Connection.Open();
            Query = "SELECT * FROM StockOutputsRelation;";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<StockOutput> stockOutputs = new List<StockOutput>();
            int SL = 0;

            while (Reader.Read())
            {
                SL = SL + 1;
                StockOutput aStockOutput = new StockOutput();
                aStockOutput.ItemId = (int)Reader["ItemId"];
                aStockOutput.ItemName = Reader["ItemName"].ToString();
                aStockOutput.CompanyId = (int)Reader["CompanyId"];
                aStockOutput.CompanyName = Reader["CompanyName"].ToString();
                aStockOutput.StockOutQunatity = (int)Reader["StockOutQunatity"];
                aStockOutput.SL = SL;
                stockOutputs.Add(aStockOutput);
            }
            Reader.Close();
            Connection.Close();
            return stockOutputs;
        }
        public int SellStockOutputlist(List<StockOutput> selList )
        {
            int rowCount =0;
           Connection.Open();
            foreach (var data in selList)
            {
                Query = "insert into StockOut (CompanyId,ItemId,StockOutQuantity,StockOutTypeId,StockOutTime)values('" + data.CompanyId + "','" + data.ItemId + "','" + data.StockOutQunatity + "',1,'" + DateTime.Now.ToString("yyyy-MM-dd") + "');";
                 Command = new SqlCommand(Query, Connection);
                  rowCount = Command.ExecuteNonQuery();
                rowCount++;
            }
            
            Connection.Close();
            return rowCount;
        }
        public int DamageStockOutputlist(List<StockOutput> selList)
        {
            int rowCount = 0;
            Connection.Open();
            foreach (var data in selList)
            {
                Query = "insert into StockOut (CompanyId,ItemId,StockOutQuantity,StockOutTypeId,StockOutTime)values('" + data.CompanyId + "','" + data.ItemId + "','" + data.StockOutQunatity + "',2,'" + DateTime.Now.ToString("yyyy-MM-dd") + "');";
                Command = new SqlCommand(Query, Connection);
                rowCount = Command.ExecuteNonQuery();
                rowCount++;
            }

            Connection.Close();
            return rowCount;
        }
        public int LostStockOutputlist(List<StockOutput> selList)
        {
            int rowCount = 0;
            Connection.Open();
            foreach (var data in selList)
            {
                Query = "insert into StockOut (CompanyId,ItemId,StockOutQuantity,StockOutTypeId,StockOutTime)values('" + data.CompanyId + "','" + data.ItemId + "','" + data.StockOutQunatity + "',3,'" + DateTime.Now.ToString("yyyy-MM-dd") + "');";
                Command = new SqlCommand(Query, Connection);
                rowCount = Command.ExecuteNonQuery();
            }

            Connection.Close();
            return rowCount;
        }

        public List<StockOutput> GetAllSaleItem(string from,string to)
        {
            Connection.Open();
            Query = "select ItemName, StockOutQuantity from StockOutRelation where (StockOutTime BETWEEN '"+from+"' and '"+to+"') and StockOutTypeId = 1;";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<StockOutput> stockOutputs = new List<StockOutput>();
            int SL = 0;

            while (Reader.Read())
            {
                SL = SL + 1;
                StockOutput aStockOutput = new StockOutput();
                aStockOutput.ItemName = Reader["ItemName"].ToString();
                aStockOutput.StockOutQunatity = (int)Reader["StockOutQuantity"];
                aStockOutput.SL = SL;
                stockOutputs.Add(aStockOutput);
            }
            Reader.Close();
            Connection.Close();
            return stockOutputs;
        }


    }
}